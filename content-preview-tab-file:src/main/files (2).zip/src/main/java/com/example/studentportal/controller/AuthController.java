package com.example.studentportal.controller;

import com.example.studentportal.model.User;
import com.example.studentportal.repository.InMemoryUserRepo;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Controller
public class AuthController {

  private final InMemoryUserRepo userRepo;
  private final PasswordEncoder passwordEncoder;

  public AuthController(InMemoryUserRepo userRepo, PasswordEncoder passwordEncoder) {
    this.userRepo = userRepo;
    this.passwordEncoder = passwordEncoder;
  }

  @GetMapping({"/", "/login"})
  public String loginPage(@RequestParam(value = "error", required = false) String error,
                          @RequestParam(value = "logout", required = false) String logout,
                          Model model) {
    model.addAttribute("error", error != null);
    model.addAttribute("logout", logout != null);
    return "login";
  }

  @GetMapping("/register")
  public String registerForm(Model model) {
    model.addAttribute("registration", new RegistrationForm());
    return "register";
  }

  @PostMapping("/register")
  public String registerSubmit(@Valid @ModelAttribute("registration") RegistrationForm form,
                               BindingResult bindingResult,
                               Model model) {
    if (bindingResult.hasErrors()) {
      return "register";
    }
    if (userRepo.existsByUsername(form.getUsername())) {
      model.addAttribute("userExists", true);
      return "register";
    }
    User u = new User(form.getUsername(), passwordEncoder.encode(form.getPassword()), List.of("ROLE_USER"));
    userRepo.save(u);
    return "redirect:/login";
  }

  public static class RegistrationForm {
    @NotBlank
    @Size(min = 3, max = 50)
    private String username;

    @NotBlank
    @Size(min = 4, max = 100)
    private String password;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
  }
}