package com.example.studentportal.repository;

import com.example.studentportal.model.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Repository;
import org.springframework.security.crypto.password.PasswordEncoder;

import jakarta.annotation.PostConstruct;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.List;

@Repository
public class InMemoryUserRepo implements UserDetailsService {

  private final Map<String, User> users = new ConcurrentHashMap<>();
  private final PasswordEncoder passwordEncoder;

  public InMemoryUserRepo(PasswordEncoder passwordEncoder) {
    this.passwordEncoder = passwordEncoder;
  }

  @PostConstruct
  public void init() {
    // default user: user / password
    save(new User("user", passwordEncoder.encode("password"), List.of("ROLE_USER")));
    // admin
    save(new User("admin", passwordEncoder.encode("adminpass"), List.of("ROLE_ADMIN", "ROLE_USER")));
  }

  public User save(User user) {
    users.put(user.getUsername(), user);
    return user;
  }

  public boolean existsByUsername(String username) {
    return users.containsKey(username);
  }

  @Override
  public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
    User u = users.get(username);
    if (u == null) throw new UsernameNotFoundException("User not found: " + username);
    return u;
  }
}