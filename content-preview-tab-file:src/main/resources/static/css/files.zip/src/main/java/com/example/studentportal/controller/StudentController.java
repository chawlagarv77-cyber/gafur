package com.example.studentportal.controller;

import com.example.studentportal.model.Student;
import com.example.studentportal.repository.InMemoryStudentRepo;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class StudentController {

  private final InMemoryStudentRepo studentRepo;

  public StudentController(InMemoryStudentRepo studentRepo) {
    this.studentRepo = studentRepo;
  }

  @GetMapping("/dashboard")
  public String dashboard(Model model) {
    model.addAttribute("students", studentRepo.findAll());
    return "dashboard";
  }

  @GetMapping("/student/new")
  public String newStudentForm(Model model) {
    model.addAttribute("student", new Student());
    return "student_form";
  }

  @PostMapping("/student")
  public String createStudent(@Valid @ModelAttribute("student") Student student,
                              BindingResult bindingResult,
                              Model model) {
    if (bindingResult.hasErrors()) {
      return "student_form";
    }
    if (!student.isAcceptedTerms()) {
      model.addAttribute("termsError", true);
      return "student_form";
    }
    studentRepo.save(student);
    return "redirect:/dashboard";
  }

  @GetMapping("/terms")
  public String terms() {
    return "terms";
  }
}